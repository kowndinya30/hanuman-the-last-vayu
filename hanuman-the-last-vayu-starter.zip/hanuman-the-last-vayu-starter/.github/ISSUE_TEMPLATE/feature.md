---
name: Feature
about: Gameplay/technical feature
---
## Goal
## Player value
## Acceptance criteria
## Dependencies
## Performance considerations
## Cultural/source considerations
## Test plan
