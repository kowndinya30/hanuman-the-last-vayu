# Game Design Document v0.1

## Product thesis
A premium cinematic action-adventure centered on Hanuman's strength, intelligence, devotion, memory and movement. The game avoids reducing Hanuman to a rage-driven superhero and builds mechanics around judgment, protection, reconnaissance, diplomacy, traversal and overwhelming force used with purpose.

## Player pillars
1. **Bal** — scale, strength, grappling, terrain interaction and destructive capability.
2. **Buddhi** — perception, stealth, language, puzzles, investigation and tactical judgment.
3. **Bhakti** — alignment with vows, protection, service and restraint; not a generic mana system.
4. **Smriti** — recovered identity and remembered capability; supports progression without implying arbitrary loss of divinity.
5. **Vayu** — momentum, leaps, aerial redirection, pressure, sound and environmental response.

## Campaign spine
Prologue: childhood and the Sun leap. Kishkindha: Hanuman meets Rama through speech and discernment. Search: southern expedition and Jambavan's reminder. Sundara: ocean crossing, Mainaka, Surasa, Simhika, Lanka infiltration, Sita, Ravana's court and Lanka burning. Yuddha: war-scale protection and rescue, culminating in the medicinal-mountain mission. Epilogue: Ayodhya and the vow to remain while Rama's story is told. Post-credit: Kali Yuga and the original-fiction continuation.

## Gameplay loop
Explore -> perceive -> choose approach -> traverse -> resolve encounter -> protect/restore objective -> recover memory/knowledge -> unlock systemic mastery -> return consequence to hub/story.

## Failure philosophy
For an immortal/chiranjeevi protagonist, failure is usually objective-based: a protected life lost, vow broken, stealth compromised, rescue window missed, civilian zone endangered, information lost or Dharma-aligned intent abandoned. Conventional death/reload is not the sole dramatic language.
