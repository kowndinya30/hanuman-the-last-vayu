# Production Roadmap v0.1

## Phase 0 — Foundation
Company/IP chain of title, source policy, cultural advisors, core leadership, GDD/TDD, visual bible, financial assumptions, repository and production tracking.

## Phase 1 — Prototype
Movement/scale prototype, combat feel, camera, Vayu environmental response, one stealth encounter, one dialogue encounter, one boss/trial, performance spike tests.

## Phase 2 — Vertical slice
Recommended slice: Jambavan reminder -> Mahendra launch -> ocean traversal/trial -> first Lanka infiltration. Demonstrates emotion, traversal, scale, stealth, cinematic transition, environment quality and UE5 performance in one package.

## Phase 3 — Full production
Content teams scale after vertical-slice greenlight. Lock chapter dependency map, asset budget, outsourcing standards, mocap plan, localization pipeline and console compliance ownership.

## Phase 4 — Alpha/Beta/Certification
Feature complete -> content complete -> optimization -> accessibility -> localization -> QA -> ratings -> platform certification -> release candidate.

## Governance
Weekly production review, fortnightly creative review, monthly budget/burn review, milestone acceptance criteria, risk register, change-control process and investor/publisher reporting cadence.
