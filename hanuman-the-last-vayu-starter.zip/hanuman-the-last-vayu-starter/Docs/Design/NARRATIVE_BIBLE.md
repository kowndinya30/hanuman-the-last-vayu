# Narrative Bible v0.1

## Canon firewall
Tag every scene `PRIMARY`, `LATER_TRADITION`, or `ORIGINAL`. Original game fiction must never be marketed as scripture.

## Primary spine
Valmiki Ramayana: relevant Kishkindha, Sundara, Yuddha and received Uttara Kanda material. Sundara Kanda is the dramatic heart: memory, leap, reconnaissance, Sita, diplomacy, strategic destruction and return with hope.

## Cross-epic continuity
Mahabharata Vana Parva: Hanuman and Bhima. Kapidhvaja tradition: Hanuman associated with Arjuna's banner, used without rewriting the Mahabharata around him.

## Working subtitle
“The Last Vayu” is an original franchise phrase. It does not mean scripture calls Hanuman the final son of Vayu. In-world it means the last great embodied guardian from Rama's age carrying the living current of sacred breath, memory and service into Kali Yuga.

## Original Kali Yuga hook
At a remote Ramakatha, the wind stops and an elderly storyteller cannot remember the next line. Hanuman awakens because the story fails to continue. The antagonist initially manifests as “The Silence”: memory severed from meaning. The final conflict tests whether limitless power can protect meaning without becoming domination.
