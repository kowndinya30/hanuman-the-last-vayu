# Technical Design Document v0.1

## Engine
Unreal Engine 5.x; exact production version must be locked at vertical-slice kickoff after plugin/platform compatibility review.

## Architecture domains
Character movement; Enhanced Input; Gameplay Tags; ability/state framework; animation state/warping; scalable traversal; combat; AI; perception/stealth; dialogue/statecraft; quest/objective state; cinematics; save/load; accessibility; telemetry; localization; build automation.

## Hanuman-specific technical problems
Seamless scale changes without camera/physics breakage; high-speed traversal with world streaming; foliage/cloth/debris pressure response; airborne combat; extreme jumps without visible streaming failure; destructibility budgets; readable facial performance during power states; transitions between stealth-scale and colossal-scale gameplay.

## Performance gates
PC min/recommended targets must be profiled from the vertical slice. PS5 performance claims remain targets until tested on authorized development hardware. No 4K/60 or platform-certification claim is to appear in investor/public material as achieved before evidence exists.

## Source control
Git + Git LFS. Binary UE assets, source DCC files, audio and video use LFS. Console SDKs, credentials, signing material and restricted platform documentation never enter the repository.
