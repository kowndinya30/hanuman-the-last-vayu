# Scriptural & Research Source Policy v0.1

## Tier A
Valmiki Ramayana narrative spine with edition/translation, Kanda, Sarga and verse-level citations recorded before screenplay lock.

## Tier B
Mahabharata cross-epic continuity, including Bhima-Hanuman and Kapidhvaja material, edition-tagged.

## Tier C
Puranic, devotional, regional, temple and oral traditions. Every inclusion must identify the actual work/edition/tradition. “Hanuman Purana” is not treated as a single standardized Mahapurana without identifying the specific source meant.

## Tier D
Original game fiction. Must be explicitly tagged and cannot be represented as a discovered religious/historical fact.

## Research fields for every adapted scene
Scene ID; source tier; work; edition; language; Kanda/Parva; Sarga/chapter; verse range; translation; variant notes; original additions; cultural reviewer; legal/IP note; canon status.
