# Investor & Publisher Readiness v0.1

## Required evidence before formal raise
Clear legal entity; founder/shareholder structure; IP assignments; trademark search/strategy; source and cultural review plan; core team CVs; vertical-slice plan; production schedule; headcount model; outsourcing plan; monthly burn; funding ask tied to milestone; use of funds; market/comparable analysis; platform/publisher strategy; revenue scenarios with assumptions; risk register; data room index; playable/captured proof where claims are made.

## Pitch narrative
1. Vision and player promise
2. Why Hanuman / global mythic action opportunity
3. Authentic creative differentiation
4. Core gameplay pillars
5. Story/campaign architecture
6. Visual identity
7. Vertical-slice proof plan
8. Market and comparables
9. Production strategy and team
10. Technology and scalability
11. Business model and release strategy
12. Budget, ask and use of funds
13. Milestones and de-risking
14. IP/cultural stewardship
15. Long-term franchise opportunity

## Claims policy
Separate vision, target, prototype evidence and achieved metrics. Do not imply Sony approval, ratings certification, publisher backing, actor attachment, trademark registration or secured funding unless documented.
