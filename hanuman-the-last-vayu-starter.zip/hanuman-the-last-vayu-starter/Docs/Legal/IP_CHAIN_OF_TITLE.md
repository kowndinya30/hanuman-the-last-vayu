# IP, Chain-of-Title & Legal Readiness v0.1

## Workstreams
Studio incorporation and cap table; founder IP assignment; employment/contractor invention assignment; commissioned art/music/voice/mocap agreements; AI/generated-asset provenance; software/plugin licenses; third-party asset licenses; font licenses; trademark clearance for title/logo; domain/social handle review; privacy/data obligations; ratings; platform/publisher contracts; insurance requirements.

## Mythology policy
Underlying ancient religious/literary traditions are not to be claimed as proprietary. Protectable assets are the project's original expression: title/brand subject to clearance, logo, original screenplay, code, art direction, models, environments, original characters/enemies, music, cinematics and specific game systems/implementation where applicable.

## Cultural safeguards
Maintain source-to-scene traceability, Sanskrit/regional language review, religious/cultural consultation, and a red-line register. Sacred quotations/mantras require exact sourcing and context review; devotional objects should not be treated as generic loot.
