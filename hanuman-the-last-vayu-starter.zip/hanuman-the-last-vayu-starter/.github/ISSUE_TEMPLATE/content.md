---
name: Content
about: Narrative/art/level content
---
## Scene / asset
## Source tag
PRIMARY / LATER_TRADITION / ORIGINAL
## Source citation
## Creative intent
## Required assets
## Cultural review
## Acceptance criteria
