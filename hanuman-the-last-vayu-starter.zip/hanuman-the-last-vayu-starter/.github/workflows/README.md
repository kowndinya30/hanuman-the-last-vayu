# CI placeholder
Do not add Unreal build workflows until runner licensing, engine installation, secrets handling and target-platform restrictions are defined. Console SDK material must never be placed in public/shared CI runners.
